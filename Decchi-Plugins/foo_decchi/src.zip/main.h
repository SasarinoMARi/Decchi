#pragma once

#include "stdafx.h"

class decchi_init : public initquit
{
private:
    HANDLE        m_hThread;

public:
    virtual void on_init();
    virtual void on_quit();
};

class decchi_callback : public main_thread_callback
{
private:
    static service_ptr_t<titleformat_object> m_format;

    HANDLE m_hPipe;

public:
    decchi_callback(HANDLE hPipe);
    void callback_run();
};

static initquit_factory_t<decchi_init> foo_initquit;
