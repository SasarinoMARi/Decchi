﻿#include "stdafx.h"
#include "main.h"

#define PIPE_NAME       L"\\\\.\\pipe\\93A0636E-29FB-4DF5-AA8E-C78860C4A624"
#define PIPE_FORMAT     "title=%title%||" \
                        "album=%album%||" \
                        "artist=$if(%album artist%,%album artist%,%artist%)||" \
                        "track=%tracknumber%||" \
                        "ttrack=%totaltracks%||" \
                        "disc=%discnumber%||" \
                        "tdisc=%totaldiscs%||" \
                        "genre=%genre%||" \
                        "year=%date%||" \
                        "path=%path%"

DECLARE_COMPONENT_VERSION("Decchi extension for Foobar2000", "1.1", "Publish #NowPlaying with Decchi\n\nMade by RyuaNerin & Sasarino MARi\n\n\n\nDecchi v1.9.0.0");
VALIDATE_COMPONENT_FILENAME("foo_decchi.dll");

void pipeStream()
{
    HANDLE hPipe = NULL;

    while (1)
    {
        if (hPipe == NULL)
        {
            hPipe = ::CreateNamedPipe(PIPE_NAME, PIPE_ACCESS_OUTBOUND, PIPE_TYPE_BYTE, 1, 0, 0, PIPE_NOWAIT, NULL);
            if (hPipe == INVALID_HANDLE_VALUE)
                return;
        }

        if (::ConnectNamedPipe(hPipe, NULL))
        {
            static_api_ptr_t<main_thread_callback_manager>()->add_callback(new service_impl_t<decchi_callback>(hPipe));
            hPipe = NULL;
        }
    }

    return;
}

DWORD WINAPI runPipe(LPVOID value)
{
    while (1)
        pipeStream();

    return 0;
}

void decchi_init::on_init()
{
    DWORD   serverThreadId;
    int     threadExited;

    this->m_hThread = ::CreateThread(NULL, 0,  runPipe, &threadExited, 0, &serverThreadId);
}

void decchi_init::on_quit()
{
    if (this->m_hThread != NULL)
        ::TerminateThread(this->m_hThread, 0);
}

service_ptr_t<titleformat_object> decchi_callback::m_format = NULL;

decchi_callback::decchi_callback(HANDLE hPipe)
{
    m_hPipe = hPipe;
}

void decchi_callback::callback_run()
{
    if (this->m_hPipe != NULL)
    {
        metadb_handle_ptr                   handle;
        static_api_ptr_t<playback_control>  control;

        if (decchi_callback::m_format == NULL)
            static_api_ptr_t<titleformat_compiler>()->compile(decchi_callback::m_format, PIPE_FORMAT);

        if (control->get_now_playing(handle))
        {
            pfc::string8 text;
            if (control->playback_format_title_ex(handle, NULL, text, decchi_callback::m_format, NULL, play_control::display_level_titles))
            {
                const char* str = text.c_str();

                DWORD written;
                ::WriteFile(this->m_hPipe, str, strlen(str) * sizeof(char), &written, NULL);
            }
        }

        DisconnectNamedPipe(this->m_hPipe);
        CloseHandle(this->m_hPipe);

        this->m_hPipe = NULL;
    }
}
