#pragma once

#include <Windows.h>

#include <cstdlib>

#include <string>

#include "foobar2000\SDK\foobar2000.h"
#include "pfc\pfc.h"
